package Graphics;

import javax.swing.*;

public class ZooPanel extends JPanel {
}
