package Animals;

public interface LandAnimal {
    public int NumberOfLegs();
}
